<?php
 
    $polaczenie = mysqli_connect("localhost","root","","wedkowanie");

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedkowanie</title>
    <link rel="stylesheet" href="styl_1.css">
</head>
<body>
    <section id="baner">
        <h1>Portal dla wedkarzy</h1>
    </section>
    <section id="lewy1">
        <h3>Ryby zamieszkujace rzeki</h3>
            
            <ol>
            <?php
                $sql = "SELECT ryby.nazwa, lowisko.akwen, lowisko.wojewodztwo FROM ryby INNER JOIN lowisko ON ryby.id = lowisko.Ryby_id WHERE lowisko.rodzaj = 3;";
                $rezultat = mysqli_query($polaczenie,$sql);
                $liczba_wierszy = mysqli_num_rows($rezultat);
                if($liczba_wierszy>0){
                    while($row = mysqli_fetch_row($rezultat)){
                        
                        echo '<li>'.$row[0].' plywa w rzece '.$row[1].', '.$row[2].'</li>';
                    }
                }else{
                    echo "brak ryb mieszkajacych w rzekach";
                }
                
            ?>    
        </ol>
    </section>
    <section id="prawy">
        <img src="ryba1.png" alt="Sum">
        <br>
        <a href="kwerendy.txt">Pobierz kwerendy</a>
    </section>
    <section id="lewy2">
            <form action="" method="GET">
                <select name="place">
                    <option value="stawy"></option>
                    <option value="jeziora"></option>
                    <option value="rzeki"></option>
                    <option value="morza"></option>
                    <option value="oceany"></option>\
                </select>
            </form>    
        <h3>Ryby drapiezne naszych wod</h3>
        <table>
            <tr>
                <th>Lp</th>
                <th>Gatunek</th>
                <th>Wystepowanie</th>
            </tr>
            <?php

                $sql = "SELECT id, nazwa, wystepowanie FROM ryby WHERE styl_zycia = 1;";
                $rezultat = mysqli_query($polaczenie,$sql);
                $liczba_wierszy = mysqli_num_rows($rezultat);
                if($liczba_wierszy>0){
                    $lp=1;
                    while($row = mysqli_fetch_row($rezultat)){
                        
                        echo '<tr><td>'.$lp.'</td><td>'.$row[1].'</td><td>'.$row[2].'</td></tr>';
                        $lp++;
                    }
                }else{
                    echo "<tr>
                    <td colspan='3'>Brak danych</td>
                    </tr>";
                }
                
            ?>     
        </table>
    </section>
    <section id="stopka">
        <p>Strone wykonal Michal Hryniewicz</p>
    </section>
</body>
</html>

<?php

    mysqli_close($polaczenie);

?>